/**
 * Created by asim on 4/11/17.
 */
// Player weapons. Ammo is unlimited for all of them.
var WEAPONS = [
    {name: 'RIFLE',   rate: 130,  speed: 22, damage: 1, color: '#fffb42', width: 5, pellets: 1, spread: 0.02},
    {name: 'SHOTGUN', rate: 650,  speed: 18, damage: 1, color: '#ff9a3c', width: 4, pellets: 6, spread: 0.22, life: 26},
    {name: 'SNIPER',  rate: 850,  speed: 40, damage: 3, color: '#7df9ff', width: 3, pellets: 1, spread: 0},
    {name: 'ROCKET',  rate: 1000, speed: 14, damage: 3, color: '#ff4040', width: 9, pellets: 1, spread: 0, splash: 150}
];

function Weapon(ctx, collisionHandler, actorType, resources){

    var _this;
    this._init = function () {

        _this = this;
        this.resources = resources;
        this.ctx = ctx;
        this.collisionHandler = collisionHandler;
        this.offset = {x: 20, y: 60};

        this.actorType = actorType;
        if(actorType == 'shyame') {

            this.weaponImageRight = this.resources.getImage('hand_with_gun');
            this.weaponImageLeft = this.resources.getImage('hand_with_gun_left');
        }else if(actorType == 'robot-unit'){

            this.weaponImageRight = this.resources.getImage('enemy_gun');
            this.weaponImageLeft = this.resources.getImage('enemy_gun_left');
        }
    };
    
    this.fireBullet = function (startPosition, endPosition, opts) {

        return new Bullet(_this.ctx, startPosition, endPosition, collisionHandler, _this.offset, _this.actorType, opts);
    };

    this._init();
}