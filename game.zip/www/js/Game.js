/**
 * Created by Asim on 4/6/2017.
 */
function Game(canvas, resources) {

    var _this;
    this._init = function() {
        
        _this = this;
        this.resources = resources;
        this.canvas = canvas;
        this.ctx = this.canvas.getContext('2d');
        this.messageBox = document.getElementById('messageBox');
        this.ground = new TileGround(this.ctx);
        this.collisionHandler = new CollisionHandler(this.ctx, this.camera, this.ground.mapArray);
        this.gameBullets = [];
        this.weaponIndex = 0;
        this.lastShotTime = 0;
        this.lastGrenadeTime = 0;
        this.grenades = [];
        this.explosions = [];
        this.aimDir = null;
        this.shyame = new Shyame(this.ctx, { x: 600, y: 200 }, this.canvas, this.camera, this.collisionHandler, this.resources);
        this.camera = new Camera(this.ctx, this.shyame);
        this.robotUnits = {};

        this.introAudio = this.resources.getAudio('intro');
        this.introAudio.play();

        var randomNoOfRobotUnits = 6;
        this.robotUnitsGenerateInterval = setInterval(
            function() {
                if(Object.size(_this.robotUnits) < randomNoOfRobotUnits)
                    _this.generateRobotUnit();
            }, 3000
        );

        this.addControls();

        this.gameAnimationFrame = requestAnimationFrame(this.drawGame);
    };

    this.showEnemyDirection = function () {

        var offsetY = 100;
        var directionCount = 0;
        for(var i = 0; i < Object.size(_this.robotUnits); i++){

            // console.log(Object.size(_this.gameBullets));
            // console.log(Object.size(_this.shyame.actor.gameBullets));
            // console.log(Object.size(_this.robotUnits[i].gameBullets));

            var distX = _this.robotUnits[i].position.x - _this.shyame.actor.position.x;
            var distY = _this.robotUnits[i].position.y - _this.shyame.actor.position.y;
            var cOffset = 200;
            var distance = Util.calculateDistance(_this.robotUnits[i].position.x, _this.robotUnits[i].position.y, _this.shyame.actor.position.x,  _this.shyame.actor.position.y);
            if(distance < 600 || directionCount == 2) {
                directionCount = 0;
                break;
            }
            var vectorX = distX / distance;
            var vectorY = distY / distance;

            var tBaseX = _this.shyame.actor.position.x + vectorX * cOffset;
            var tBaseY = _this.shyame.actor.position.y + vectorY * cOffset;
            var tDistance = Util.calculateDistance(_this.robotUnits[i].position.x, _this.robotUnits[i].position.y, tBaseX,  tBaseY);

            var tDistX = _this.robotUnits[i].position.x - tBaseX;
            var tDistY = _this.robotUnits[i].position.y - tBaseY;
            var tVectorX = tDistX / tDistance;
            var tVectorY = tDistY / tDistance;
            var tOffset = 20;

            var xPerp = tOffset * tVectorX;
            var yPerp = tOffset * tVectorY;

            var cx = tBaseX - yPerp;
            var cy = tBaseY + xPerp;
            var dx = tBaseX + yPerp;
            var dy = tBaseY - xPerp;

            _this.ctx.beginPath();
            _this.ctx.lineWidth = 3;

            _this.ctx.moveTo(tBaseX + tVectorX * tOffset, tBaseY + tVectorY * tOffset);
            _this.ctx.lineTo(cx, cy);
            _this.ctx.lineTo(dx, dy);
            _this.ctx.lineTo(tBaseX + tVectorX * tOffset, tBaseY + tVectorY * tOffset);

            _this.ctx.strokeStyle = '#ff0000';
            _this.ctx.stroke();
            _this.ctx.strokeStyle = '#fff';
            _this.ctx.closePath();
            _this.ctx.beginPath();
            // _this.ctx.arc(_this.shyame.actor.position.x, _this.shyame.actor.position.y, cOffset, 0, Math.PI * 2);
            _this.ctx.stroke();
            _this.ctx.closePath();
            directionCount++;
        }
    };

    this.generateRobotUnit = function () {

        var rx = Util.getRandomInt(0, _this.canvas.width/3);
        var ry = Util.getRandomInt(-_this.canvas.height, 0);
        var robotUnit = new RobotUnit(Object.size(_this.robotUnits), _this.ctx, {x: rx, y: ry}, _this.shyame, _this.robotUnits, _this.ground.mapArray, _this.collisionHandler, _this, _this.resources);
        _this.robotUnits[Object.size(_this.robotUnits)] = robotUnit;
    };

    this.drawRobotUnits = function () {

        for(var i = 0; i < Object.size(_this.robotUnits); i++) {
            _this.robotUnits[i].move();
            _this.robotUnits[i].drawWeapon();
            _this.robotUnits[i].drawHealthOverHead();
        }
    };

    this.drawGame = function() {

        _this.gameAnimationFrame = requestAnimationFrame(_this.drawGame);
        _this.ctx.clearRect(0, 0, _this.ctx.canvas.width, _this.ctx.canvas.height);
        _this.ground.drawGround();
        _this.camera.move();
        _this.drawRobotUnits();
        _this.showEnemyDirection();
        _this.shyame.actor.move();
        _this.shyame.actor.drawWeapon();
        _this.shyame.actor._drawShyameStatus();
        _this.applyAim();
        _this.drawFire();
        _this.drawGrenades();
        _this.drawExplosions();
        _this.checkShot();
        _this.drawHud();
    };

    this.drawFire = function () {

        var refreshedGameBullets = {};
        var count = 0;
        if(Object.size(_this.gameBullets) > 0){
            // console.log(_this.gameBullets);
        }
        for(var i in _this.gameBullets){

            var gb = _this.gameBullets[i];
            if(gb.life && gb.age > gb.life){
                gb.hit = true;
            }
            if(gb.hit){
                continue;
            }
            if(gb.toPosition.x > _this.ctx.canvas.width
                || _this.gameBullets[i].toPosition.y > _this.ctx.canvas.height
                || _this.gameBullets[i].toPosition.x < 0
                || _this.gameBullets[i].toPosition.y < 0
                || _this.collisionHandler.objectIsOutBound(_this.gameBullets[i].toPosition)){

                if(gb.splash && gb.flew && gb.actorType == 'shyame'){
                    _this.explode(gb.fromPosition.x, gb.fromPosition.y, gb.splash, gb.damage);
                }
                _this.gameBullets[i] = null;
            }else if(!_this.gameBullets[i].hit){
                refreshedGameBullets[count] = _this.gameBullets[i];
                _this.gameBullets[i].fire();
                count += 1;
            }
        }

        _this.gameBullets = refreshedGameBullets;
    };

    this.checkShot = function () {

        if(_this.shyame.actor.health == 0){

            if(_this.shyame.actor.noOfLifes > 1) {
                _this.respawn();
            }else{
                _this.gameOver();
            }
        }
        var refreshedBullets = {};
        var refreshedBulletsCount = 0;
        for(var i = 0; i < Object.size(_this.gameBullets); i++){
            if(_this.gameBullets[i].actorType == 'shyame') {
                var bl = _this.gameBullets[i];
                for (var j = 0; j < Object.size(_this.robotUnits); j++) {
                    var rb = _this.robotUnits[j];
                    if (!rb.dead && _this.rectCircleColliding(bl, rb)) {
                        bl.hit = true;
                        if (bl.splash) {
                            _this.explode(bl.toPosition.x, bl.toPosition.y, bl.splash, bl.damage);
                        } else {
                            _this.damageRobot(rb, bl.damage);
                        }
                        break;
                    }
                }
                _this.cleanRobots();
            }else if(_this.gameBullets[i].actorType == 'robot-unit'){

                if (_this.rectCircleColliding(_this.gameBullets[i], _this.shyame.actor)) {

                    if (_this.shyame.actor.health >= 50){

                        _this.shyame.actor.health -= 50;
                    }else if(_this.shyame.actor.health > 0) {

                        _this.shyame.actor.health = 0;
                    }

                    _this.gameBullets[i].hit = true;
                }
            }
            if (!refreshedBullets.hasOwnProperty(i) && !_this.gameBullets[i].hit) {
                refreshedBullets[refreshedBulletsCount] = _this.gameBullets[i];
                refreshedBulletsCount += 1;
            }
        }
        _this.gameBullets = refreshedBullets;
    };

    // returns true if the actor and bullet are colliding
    this.rectCircleColliding = function(bullet, actor) {
        var distX = Math.abs(bullet.toPosition.x - actor.position.x - actor.actorWidth / 2);
        var distY = Math.abs(bullet.toPosition.y - actor.position.y - actor.actorHeight / 2);

        if (distX > (actor.actorWidth / 2 + 5)) {
            return false;
        }
        if (distY > (actor.actorHeight / 2 + 5)) {
            return false;
        }
        if (distX <= (actor.actorWidth / 2)) {
            return true;
        }
        if (distY <= (actor.actorHeight / 2)) {
            return true;
        }

        var dx = distX - actor.actorWidth / 2;
        var dy = distY - actor.actorHeight / 2;
        return (dx * dx + dy * dy <= 25);
    };

    this.respawn = function () {

        _this.respawnTime = 6;
        _this.pauseGame();
        _this.messageBox.style.opacity = 1;
        document.getElementById('score').innerHTML = _this.shyame.actor.score;
        document.getElementById('kills').innerHTML = _this.shyame.actor.kills;
        document.getElementById('respawn-value').innerHTML = _this.respawnTime;

        _this.respawnInterval = setInterval(function () {

            if(_this.respawnTime == 0){

                _this.resumeGame();
                _this.shyame.actor.noOfLifes -= 1;
                _this.shyame.actor.health = _this.shyame.actor.maxHealth;
                clearInterval(_this.respawnInterval);
            }else {
                _this.respawnTime -= 1;
                document.getElementById('respawn-value').innerHTML = _this.respawnTime;
            }
        }, 1000);

        _this.shyame.actor.position = {x: 1400, y: 10};
    };

    this.pauseGame = function () {

        cancelAnimationFrame(_this.gameAnimationFrame);
    };

    this.resumeGame = function () {

        _this.messageBox.style.opacity = 0;
        _this.gameAnimationFrame = requestAnimationFrame(_this.drawGame);
    };

    this.gameOver = function () {

        _this.messageBox.style.opacity = 1;
        document.getElementById('messageHeading').innerHTML = 'GAME OVER';
        document.getElementById('score').innerHTML = _this.shyame.actor.score;
        document.getElementById('kills').innerHTML = _this.shyame.actor.kills;
        document.getElementById('respawn').innerHTML = '';
        document.getElementById('retryButton').style.display = 'block';

        _this.pauseGame();
        _this.removeControls();
        _this.messageBox.style.opacity = 1;
        // _this._init();
    };

    this.addMovements = function(e) {

        _this.shyame.actor.commands['G'] = false;
        _this.shyame.actor.commands['O'] = false;
        switch (e.which) {

            case 87:
                _this.shyame.actor.commands['W'] = true;
                break;
            case 83:
                _this.shyame.actor.commands['S'] = true;
                break;
            case 68:
                _this.shyame.actor.commands['D'] = true;
                break;
            case 65:
                _this.shyame.actor.commands['A'] = true;
                break;
            case 49: case 50: case 51: case 52:
                _this.switchWeapon(e.which - 49);
                break;
            case 81:
                _this.switchWeapon();
                break;
            case 69:
                _this.throwGrenade();
                break;
        }
    };

    this.removeMovements = function(e) {

        switch (e.which) {

            case 87:
                _this.shyame.actor.commands['W'] = false;
                break;
            case 83:
                _this.shyame.actor.commands['S'] = false;
                break;
            case 68:
                _this.shyame.actor.commands['D'] = false;
                break;
            case 65:
                _this.shyame.actor.commands['A'] = false;
                break;
        }
    };

    this.updateFaceSideEvent = function(e) {

        _this.shyame.actor.mousePos = _this.getMousePos(_this.canvas, e);
        _this.shyame.actor._updateFaceSide();
    };

    this.fireBulletEvent = function(e){

        _this.resources.getAudio('gun_shot').currentTime = 0;
        _this.gameBullets[Object.size(_this.gameBullets)] = _this.shyame.actor.weapon.fireBullet(_this.shyame.actor.position, _this.getMousePos(_this.canvas, e));
        _this.resources.getAudio('gun_shot').play();
    };

    // ---------- enemies / damage ----------
    this.damageRobot = function (robot, dmg) {
        if (robot.dead) return;
        robot.hitCount += dmg;
        if (robot.hitCount >= robot.maxRobotHit) {
            robot.dead = true;
            _this.shyame.actor.score += 100;
            _this.shyame.actor.kills += 1;
            robot.death();
        }
    };

    this.cleanRobots = function () {
        var alive = {}, n = 0;
        for (var k = 0; k < Object.size(_this.robotUnits); k++) {
            if (!_this.robotUnits[k].dead) { alive[n] = _this.robotUnits[k]; n++; }
        }
        _this.robotUnits = alive;
    };

    this.explode = function (x, y, radius, dmg) {
        _this.explosions.push({x: x, y: y, t: 0, max: radius});
        for (var k = 0; k < Object.size(_this.robotUnits); k++) {
            var r = _this.robotUnits[k];
            var cx = r.position.x + r.actorWidth / 2, cy = r.position.y + r.actorHeight / 2;
            if (Util.calculateDistance(x, y, cx, cy) <= radius + 30) _this.damageRobot(r, dmg);
        }
        _this.cleanRobots();
        var snd = _this.resources.getAudio('gun_shot');
        try { snd.currentTime = 0; snd.play(); } catch (err) {}
    };

    this.drawExplosions = function () {
        var keep = [];
        for (var k = 0; k < _this.explosions.length; k++) {
            var e = _this.explosions[k];
            e.t += 1;
            var p = e.t / 22;
            if (p >= 1) continue;
            var ctx = _this.ctx;
            ctx.save();
            ctx.globalAlpha = 1 - p;
            ctx.beginPath();
            ctx.arc(e.x, e.y, e.max * (0.3 + 0.7 * p), 0, Math.PI * 2);
            ctx.fillStyle = p < 0.4 ? '#fff2a0' : '#ff7a1a';
            ctx.fill();
            ctx.restore();
            keep.push(e);
        }
        _this.explosions = keep;
    };

    // ---------- weapons ----------
    this.switchWeapon = function (index) {
        if (index === undefined) index = (_this.weaponIndex + 1) % WEAPONS.length;
        _this.weaponIndex = index;
    };

    // unlimited ammo, no reload: only a short delay between shots
    this.fireAtPos = function (pos) {
        var w = WEAPONS[_this.weaponIndex];
        var now = Date.now();
        if (now - _this.lastShotTime < w.rate) return;
        _this.lastShotTime = now;
        var a = _this.shyame.actor;
        var ox = a.position.x + a.weapon.offset.x, oy = a.position.y + a.weapon.offset.y;
        var dx = pos.x - ox, dy = pos.y - oy;
        if (Math.abs(dx) < 1 && Math.abs(dy) < 1) dx = (a.faceSide == 'left') ? -1 : 1;
        for (var p = 0; p < w.pellets; p++) {
            var ang = (Math.random() - 0.5) * 2 * w.spread;
            var rx = dx * Math.cos(ang) - dy * Math.sin(ang);
            var ry = dx * Math.sin(ang) + dy * Math.cos(ang);
            _this.gameBullets[Object.size(_this.gameBullets)] =
                a.weapon.fireBullet(a.position, {x: ox + rx, y: oy + ry}, w);
        }
        var snd = _this.resources.getAudio('gun_shot');
        try { snd.currentTime = 0; snd.play(); } catch (err) {}
    };

    this.startFire = function (getPos) {
        _this.firePosFn = getPos;
        if (_this.fireInterval) return;
        _this.fireAtPos(getPos());
        _this.fireInterval = setInterval(function () {
            _this.fireAtPos(_this.firePosFn());
        }, 30);
    };

    this.stopFire = function () {
        clearInterval(_this.fireInterval);
        _this.fireInterval = null;
    };

    // ---------- grenades (unlimited, short cooldown) ----------
    this.currentAimPos = function () {
        var a = _this.shyame.actor;
        if (_this.aimDir) {
            return {x: a.position.x + a.actorWidth / 2 + _this.aimDir.x * 400,
                    y: a.position.y + 60 + _this.aimDir.y * 400};
        }
        return a.mousePos || {x: a.position.x + 300, y: a.position.y};
    };

    this.throwGrenade = function () {
        var now = Date.now();
        if (now - _this.lastGrenadeTime < 1200) return;
        _this.lastGrenadeTime = now;
        var a = _this.shyame.actor;
        var ox = a.position.x + a.actorWidth / 2, oy = a.position.y + 40;
        var pos = _this.currentAimPos();
        var dx = pos.x - ox, dy = pos.y - oy;
        var len = Math.sqrt(dx * dx + dy * dy);
        if (len < 1) { dx = (a.faceSide == 'left') ? -1 : 1; dy = 0; len = 1; }
        _this.grenades.push({x: ox, y: oy, vx: dx / len * 11, vy: dy / len * 11 - 3, t: 0});
    };

    this.drawGrenades = function () {
        var keep = [];
        var ch = _this.collisionHandler, ctx = _this.ctx;
        for (var k = 0; k < _this.grenades.length; k++) {
            var g = _this.grenades[k];
            g.vy += 0.35;
            var nx = g.x + g.vx, ny = g.y + g.vy;
            if (ch.objectIsOutBound({x: nx, y: ny})) {
                if (ch.objectIsOutBound({x: g.x, y: ny})) { g.vy = -g.vy * 0.45; g.vx *= 0.7; }
                else { g.vx = -g.vx * 0.5; }
            } else {
                g.x = nx; g.y = ny;
            }
            g.t += 1;
            var boom = g.t >= 90 || g.y > ctx.canvas.height || g.x < 0 || g.x > ctx.canvas.width;
            if (!boom) {
                for (var j = 0; j < Object.size(_this.robotUnits); j++) {
                    if (_this.rectCircleColliding({toPosition: {x: g.x, y: g.y}}, _this.robotUnits[j])) { boom = true; break; }
                }
            }
            if (boom) {
                _this.explode(g.x, g.y, 140, 3);
            } else {
                ctx.beginPath();
                ctx.arc(g.x, g.y, 8, 0, Math.PI * 2);
                ctx.fillStyle = '#2e5d1e';
                ctx.fill();
                ctx.lineWidth = 2;
                ctx.strokeStyle = '#111';
                ctx.stroke();
                keep.push(g);
            }
        }
        _this.grenades = keep;
    };

    this.drawHud = function () {
        var ml = Math.abs(parseInt(_this.ctx.canvas.style.marginLeft));
        if (isNaN(ml)) ml = 0;
        _this.ctx.font = 'bold 22px sans-serif';
        _this.ctx.fillStyle = '#ffffff';
        _this.ctx.fillText('WEAPON: ' + WEAPONS[_this.weaponIndex].name + '   AMMO: \u221E', ml + 60, 175);
    };

    // ---------- aiming helpers ----------
    this.applyAim = function () {
        if (_this.aimDir) {
            _this.shyame.actor.mousePos = _this.currentAimPos();
            _this.shyame.actor._updateFaceSide();
        }
    };

    // right stick on phones
    this.setAim = function (dx, dy, firing) {
        _this.aimDir = {x: dx, y: dy};
        if (firing) _this.startFire(function () { return _this.currentAimPos(); });
        else _this.stopFire();
    };

    // ---------- mouse (desktop) ----------
    this.onMouseDown = function (e) {
        _this.aimDir = null;
        _this.mouseEv = {clientX: e.clientX, clientY: e.clientY};
        _this.startFire(function () { return _this.getMousePos(_this.canvas, _this.mouseEv); });
    };
    this.onMouseMove = function (e) {
        _this.mouseEv = {clientX: e.clientX, clientY: e.clientY};
        _this.aimDir = null;
        _this.updateFaceSideEvent(e);
    };
    this.onMouseUp = function () { _this.stopFire(); };

    // virtual buttons / left stick (see js/Mobile.js)
    this.setCommand = function (key, value) {
        var c = _this.shyame.actor.commands;
        if (value) { c['G'] = false; c['O'] = false; }
        c[key] = value;
    };

    this.addControls = function() {

        document.addEventListener('keydown', _this.addMovements);
        document.addEventListener('keyup', _this.removeMovements);
        document.addEventListener('mousemove', _this.onMouseMove);
        document.addEventListener('mousedown', _this.onMouseDown);
        document.addEventListener('mouseup', _this.onMouseUp);
        window.currentGame = _this;
    };

    this.removeControls = function () {

        document.removeEventListener('keydown', _this.addMovements);
        document.removeEventListener('keyup', _this.removeMovements);
        document.removeEventListener('mousemove', _this.onMouseMove);
        document.removeEventListener('mousedown', _this.onMouseDown);
        document.removeEventListener('mouseup', _this.onMouseUp);
        _this.stopFire();
    };

    this.getMousePos = function(canvas, evt) {
        var rect = canvas.getBoundingClientRect();
        var scale = window.GAME_SCALE || 1;
        return {
            x: (evt.clientX - rect.left) / scale,
            y: (evt.clientY - rect.top) / scale
        };
    }

    this._init();
}
