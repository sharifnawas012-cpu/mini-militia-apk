// Fits the 1360x645 game to the screen and provides two floating sticks:
//  left stick  = move (left/right) and jetpack (push up)
//  right stick = aim; the gun fires while the stick is held (unlimited ammo)
(function () {
    var W = 1360, H = 655;
    window.GAME_SCALE = 1;

    function fit() {
        var s = Math.min(window.innerWidth / W, window.innerHeight / H);
        window.GAME_SCALE = s;
        var w = document.querySelector('.wrapper');
        if (!w) return;
        w.style.transformOrigin = '0 0';
        w.style.transform = 'scale(' + s + ')';
        w.style.left = Math.max(0, (window.innerWidth - W * s) / 2) + 'px';
        w.style.top = Math.max(0, (window.innerHeight - H * s) / 2) + 'px';
    }
    window.addEventListener('resize', fit);
    window.addEventListener('orientationchange', fit);

    function game() { return window.currentGame; }

    function makeStick(zoneId, baseId, knobId, onMove, onEnd) {
        var zone = document.getElementById(zoneId);
        var base = document.getElementById(baseId);
        var knob = document.getElementById(knobId);
        var touchId = null, cx = 0, cy = 0, R = 60;

        function find(e) {
            for (var i = 0; i < e.changedTouches.length; i++) {
                if (e.changedTouches[i].identifier === touchId) return e.changedTouches[i];
            }
            return null;
        }
        zone.addEventListener('touchstart', function (e) {
            e.preventDefault();
            if (touchId !== null) return;
            var t = e.changedTouches[0];
            touchId = t.identifier;
            R = window.innerHeight * 0.13;
            cx = t.clientX; cy = t.clientY;
            base.style.display = 'block';
            base.style.left = (cx - R) + 'px';
            base.style.top = (cy - R) + 'px';
            knob.style.transform = 'translate(0,0)';
        }, {passive: false});
        zone.addEventListener('touchmove', function (e) {
            e.preventDefault();
            var t = find(e);
            if (!t) return;
            var dx = (t.clientX - cx) / R, dy = (t.clientY - cy) / R;
            var mag = Math.sqrt(dx * dx + dy * dy);
            if (mag > 1) { dx /= mag; dy /= mag; mag = 1; }
            knob.style.transform = 'translate(' + (dx * R) + 'px,' + (dy * R) + 'px)';
            onMove(dx, dy, mag);
        }, {passive: false});
        function end(e) {
            if (!find(e)) return;
            e.preventDefault();
            touchId = null;
            base.style.display = 'none';
            onEnd();
        }
        zone.addEventListener('touchend', end, {passive: false});
        zone.addEventListener('touchcancel', end, {passive: false});
    }

    function tap(id, fn) {
        var el = document.getElementById(id);
        el.addEventListener('touchstart', function (e) { e.preventDefault(); e.stopPropagation(); fn(); }, {passive: false});
        el.addEventListener('mousedown', function (e) { e.stopPropagation(); fn(); });
    }

    document.addEventListener('DOMContentLoaded', function () {
        fit();

        makeStick('zoneMove', 'baseMove', 'knobMove', function (dx, dy) {
            var g = game(); if (!g) return;
            g.setCommand('A', dx < -0.3);
            g.setCommand('D', dx > 0.3);
            g.setCommand('W', dy < -0.4);
            g.setCommand('S', dy > 0.6);
        }, function () {
            var g = game(); if (!g) return;
            ['A', 'D', 'W', 'S'].forEach(function (k) { g.setCommand(k, false); });
        });

        makeStick('zoneAim', 'baseAim', 'knobAim', function (dx, dy, mag) {
            var g = game(); if (!g || mag < 0.12) return;
            g.setAim(dx / mag, dy / mag, mag > 0.2);
        }, function () {
            var g = game(); if (!g) return;
            g.stopFire();
        });

        tap('btnWeapon', function () { var g = game(); if (g) g.switchWeapon(); });
        tap('btnGrenade', function () { var g = game(); if (g) g.throwGrenade(); });

        document.addEventListener('contextmenu', function (e) { e.preventDefault(); });
    });
})();
