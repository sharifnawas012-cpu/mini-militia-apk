// Scales the 1360x645 game to the phone screen and wires the on-screen buttons.
(function () {
    var W = 1360, H = 655;
    window.GAME_SCALE = 1;

    function fit() {
        var s = Math.min(window.innerWidth / W, window.innerHeight / H);
        window.GAME_SCALE = s;
        var w = document.querySelector('.wrapper');
        if (!w) return;
        w.style.transformOrigin = '0 0';
        w.style.transform = 'scale(' + s + ')';
        w.style.left = Math.max(0, (window.innerWidth - W * s) / 2) + 'px';
        w.style.top = Math.max(0, (window.innerHeight - H * s) / 2) + 'px';
    }
    window.addEventListener('resize', fit);
    window.addEventListener('orientationchange', fit);
    document.addEventListener('DOMContentLoaded', function () {
        fit();
        function bind(id, key) {
            var el = document.getElementById(id);
            function on(e) { e.preventDefault(); if (window.currentGame) window.currentGame.setCommand(key, true); }
            function off(e) { e.preventDefault(); if (window.currentGame) window.currentGame.setCommand(key, false); }
            el.addEventListener('touchstart', on, {passive: false});
            el.addEventListener('touchend', off, {passive: false});
            el.addEventListener('touchcancel', off, {passive: false});
            el.addEventListener('mousedown', on);
            el.addEventListener('mouseup', off);
            el.addEventListener('mouseleave', off);
        }
        bind('btnLeft', 'A');
        bind('btnRight', 'D');
        bind('btnJet', 'W');
        document.addEventListener('contextmenu', function (e) { e.preventDefault(); });
    });
})();
